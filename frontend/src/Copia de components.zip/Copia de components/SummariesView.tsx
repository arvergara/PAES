import { useState, useMemo } from 'react';
import { X, BookOpen, Calculator, Brain, FlaskRound as Flask, History, FileText, ChevronRight, Search } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

interface SummariesViewProps {
  onClose: () => void;
}

const subjects = [
  { code: 'M1', name: 'Matemática 1', icon: Calculator, color: 'from-blue-500 to-blue-700', topics: ['Álgebra', 'Funciones', 'Ecuaciones', 'Inecuaciones'] },
  { code: 'M2', name: 'Matemática 2', icon: Brain, color: 'from-purple-500 to-purple-700', topics: ['Geometría', 'Probabilidad', 'Estadística', 'Trigonometría'] },
  { code: 'L', name: 'Competencia Lectora', icon: BookOpen, color: 'from-rose-500 to-rose-700', topics: ['Comprensión Lectora', 'Vocabulario', 'Conectores', 'Plan de Redacción'] },
  { code: 'C', name: 'Ciencias', icon: Flask, color: 'from-emerald-500 to-emerald-700', topics: ['Física', 'Química', 'Biología'] },
  { code: 'H', name: 'Historia y Cs. Sociales', icon: History, color: 'from-amber-500 to-amber-700', topics: ['Historia de Chile', 'Historia Universal', 'Geografía', 'Educación Cívica'] },
];

export function SummariesView({ onClose }: SummariesViewProps) {
  const { isDark } = useTheme();
  const [selectedSubject, setSelectedSubject] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const selected = subjects.find(s => s.code === selectedSubject);

  // Normalizar texto para búsqueda (quitar acentos y convertir a minúsculas)
  const normalizeText = (text: string) => {
    return text
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '');
  };

  // Filtrar materias y temas basado en la búsqueda
  const filteredResults = useMemo(() => {
    if (!searchQuery.trim()) return null;

    const query = normalizeText(searchQuery);
    const results: { subject: typeof subjects[0]; matchedTopics: string[] }[] = [];

    subjects.forEach(subject => {
      const subjectNameMatch = normalizeText(subject.name).includes(query);
      const matchedTopics = subject.topics.filter(topic => 
        normalizeText(topic).includes(query)
      );

      if (subjectNameMatch || matchedTopics.length > 0) {
        results.push({
          subject,
          matchedTopics: subjectNameMatch ? subject.topics : matchedTopics
        });
      }
    });

    return results;
  }, [searchQuery]);

  // Limpiar búsqueda al seleccionar una materia
  const handleSelectSubject = (code: string) => {
    setSelectedSubject(code);
    setSearchQuery('');
  };

  // Limpiar búsqueda
  const clearSearch = () => {
    setSearchQuery('');
  };

  return (
    <div className={`min-h-screen ${isDark ? 'bg-gray-900' : 'bg-gray-50'}`}>
      {/* Header */}
      <div className={`sticky top-0 z-10 ${isDark ? 'bg-gray-900/95 border-gray-800' : 'bg-white/95 border-gray-200'} border-b backdrop-blur-sm`}>
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <FileText className={`w-6 h-6 ${isDark ? 'text-indigo-400' : 'text-indigo-600'}`} />
              <h1 className={`text-xl font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>Resúmenes PAES</h1>
            </div>
            <button onClick={onClose} className={`p-2 rounded-lg transition-colors ${isDark ? 'hover:bg-white/10 text-gray-400' : 'hover:bg-gray-100 text-gray-600'}`}>
              <X className="w-5 h-5" />
            </button>
          </div>
          
          {/* Barra de búsqueda */}
          <div className="relative max-w-md mx-auto">
            <Search className={`absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 ${isDark ? 'text-gray-500' : 'text-gray-400'}`} />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Buscar materia o tema..."
              className={`w-full pl-10 pr-10 py-2.5 rounded-xl border transition-colors ${
                isDark 
                  ? 'bg-white/5 border-white/10 text-white placeholder-gray-500 focus:border-indigo-500 focus:bg-white/10' 
                  : 'bg-white border-gray-200 text-gray-900 placeholder-gray-400 focus:border-indigo-500 focus:bg-gray-50'
              } outline-none`}
            />
            {searchQuery && (
              <button
                onClick={clearSearch}
                className={`absolute right-3 top-1/2 -translate-y-1/2 p-1 rounded-full transition-colors ${
                  isDark ? 'hover:bg-white/10 text-gray-500' : 'hover:bg-gray-100 text-gray-400'
                }`}
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>

      <main className="container mx-auto px-4 py-8">
        {/* Resultados de búsqueda */}
        {filteredResults !== null ? (
          filteredResults.length > 0 ? (
            <>
              <p className={`text-center mb-6 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
                {filteredResults.length} resultado{filteredResults.length !== 1 ? 's' : ''} para "{searchQuery}"
              </p>
              <div className="space-y-6 max-w-2xl mx-auto">
                {filteredResults.map(({ subject, matchedTopics }) => {
                  const Icon = subject.icon;
                  return (
                    <div key={subject.code} className={`rounded-2xl overflow-hidden ${isDark ? 'bg-white/5 border border-white/10' : 'bg-white border border-gray-200'}`}>
                      {/* Header de la materia */}
                      <button
                        onClick={() => handleSelectSubject(subject.code)}
                        className={`w-full p-4 flex items-center gap-3 transition-colors ${isDark ? 'hover:bg-white/5' : 'hover:bg-gray-50'}`}
                      >
                        <div className={`p-2.5 rounded-xl bg-gradient-to-br ${subject.color}`}>
                          <Icon className="w-5 h-5 text-white" />
                        </div>
                        <span className={`font-semibold ${isDark ? 'text-white' : 'text-gray-900'}`}>{subject.name}</span>
                        <ChevronRight className={`w-5 h-5 ml-auto ${isDark ? 'text-gray-600' : 'text-gray-400'}`} />
                      </button>
                      
                      {/* Temas encontrados */}
                      <div className={`px-4 pb-4 ${isDark ? 'border-t border-white/5' : 'border-t border-gray-100'}`}>
                        <p className={`text-xs uppercase tracking-wide mt-3 mb-2 ${isDark ? 'text-gray-500' : 'text-gray-400'}`}>
                          Temas encontrados
                        </p>
                        <div className="flex flex-wrap gap-2">
                          {matchedTopics.map(topic => (
                            <span 
                              key={topic} 
                              className={`px-3 py-1.5 rounded-lg text-sm ${
                                isDark 
                                  ? 'bg-indigo-500/20 text-indigo-300' 
                                  : 'bg-indigo-50 text-indigo-700'
                              }`}
                            >
                              {topic}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </>
          ) : (
            <div className="text-center py-12">
              <Search className={`w-12 h-12 mx-auto mb-4 ${isDark ? 'text-gray-600' : 'text-gray-300'}`} />
              <p className={`text-lg font-medium mb-2 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
                No se encontraron resultados
              </p>
              <p className={`text-sm ${isDark ? 'text-gray-500' : 'text-gray-400'}`}>
                Intenta con otros términos como "álgebra", "historia" o "funciones"
              </p>
            </div>
          )
        ) : !selectedSubject ? (
          /* Vista de materias */
          <>
            <p className={`text-center mb-8 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
              Selecciona una materia para ver los resúmenes disponibles
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 max-w-4xl mx-auto">
              {subjects.map((subject) => {
                const Icon = subject.icon;
                return (
                  <button
                    key={subject.code}
                    onClick={() => handleSelectSubject(subject.code)}
                    className={`p-6 rounded-2xl text-white text-left transition-all hover:scale-[1.02] hover:-translate-y-1 bg-gradient-to-br ${subject.color}`}
                  >
                    <div className="flex items-center gap-3 mb-4">
                      <div className="p-3 bg-white/20 rounded-xl">
                        <Icon className="w-6 h-6" />
                      </div>
                      <h3 className="text-lg font-bold">{subject.name}</h3>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {subject.topics.slice(0, 3).map(topic => (
                        <span key={topic} className="px-2 py-1 bg-white/20 rounded text-xs">{topic}</span>
                      ))}
                      {subject.topics.length > 3 && (
                        <span className="px-2 py-1 bg-white/20 rounded text-xs">+{subject.topics.length - 3}</span>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </>
        ) : (
          /* Vista de temas de una materia */
          <>
            <button
              onClick={() => setSelectedSubject(null)}
              className={`inline-flex items-center gap-2 px-4 py-2 rounded-xl mb-6 transition-colors ${isDark ? 'bg-white/5 hover:bg-white/10 text-gray-400' : 'bg-gray-100 hover:bg-gray-200 text-gray-600'}`}
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><polyline points="15,18 9,12 15,6"/></svg>
              Volver a materias
            </button>

            <h2 className={`text-2xl font-bold mb-6 ${isDark ? 'text-white' : 'text-gray-900'}`}>
              {selected?.name}
            </h2>

            <div className="space-y-3 max-w-2xl">
              {selected?.topics.map((topic, index) => (
                <div
                  key={topic}
                  className={`p-4 rounded-xl flex items-center justify-between cursor-pointer transition-colors ${isDark ? 'bg-white/5 hover:bg-white/10 border border-white/10' : 'bg-white hover:bg-gray-50 border border-gray-200'}`}
                >
                  <div className="flex items-center gap-4">
                    <span className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm font-bold ${isDark ? 'bg-indigo-500/20 text-indigo-400' : 'bg-indigo-100 text-indigo-600'}`}>
                      {index + 1}
                    </span>
                    <span className={`font-medium ${isDark ? 'text-white' : 'text-gray-900'}`}>{topic}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`text-sm ${isDark ? 'text-gray-500' : 'text-gray-400'}`}>Próximamente</span>
                    <ChevronRight className={`w-5 h-5 ${isDark ? 'text-gray-600' : 'text-gray-300'}`} />
                  </div>
                </div>
              ))}
            </div>

            <div className={`mt-8 p-6 rounded-xl text-center ${isDark ? 'bg-amber-500/10 border border-amber-500/20' : 'bg-amber-50 border border-amber-200'}`}>
              <p className={`${isDark ? 'text-amber-400' : 'text-amber-700'}`}>
                📚 Los resúmenes detallados estarán disponibles próximamente
              </p>
            </div>
          </>
        )}
      </main>
    </div>
  );
}