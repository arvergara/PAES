// Configuración de Supabase
// Estos valores son públicos y seguros de exponer en el frontend
export const SUPABASE_URL = 'https://bmsmmlymsjpydpealmcw.supabase.co';
export const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJtc21tbHltc2pweWRwZWFsbWN3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjU5NzMwODgsImV4cCI6MjA4MTU0OTA4OH0.B1I7SIA4r9FwYOkm7te40M-zxuG0WUVlzpXOj1tCmIo';
